package dtos

type HealthGetResponseDTO struct {
	Message string `json:"message"`
	Status  string `json:"status"`
}
