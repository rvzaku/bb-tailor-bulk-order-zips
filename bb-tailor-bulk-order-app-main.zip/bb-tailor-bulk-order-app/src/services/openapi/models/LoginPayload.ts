/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type LoginPayload = {
    /**
     * Email address of the user.
     */
    email?: string;
    /**
     * user's password for login.
     */
    password?: string;
};

