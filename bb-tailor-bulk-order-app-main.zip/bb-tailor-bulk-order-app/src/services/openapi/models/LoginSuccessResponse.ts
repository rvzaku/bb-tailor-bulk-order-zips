/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type LoginSuccessResponse = {
    /**
     * Access token generated for the user.
     */
    accessToken?: string;
    /**
     * Refresh token generated for the user.
     */
    refreshToken?: string;
};

