/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type LoginBadRequestResponse = {
    /**
     * Error message of bad request.
     */
    message?: string;
};

